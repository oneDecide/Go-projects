package main

import "fmt"

//place your custom tests here
func MyTests() {
	fmt.Println("Running custom tests")
}
